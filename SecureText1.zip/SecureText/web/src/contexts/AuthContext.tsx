import React, { createContext, useContext, useState, useEffect } from 'react'
import apiClient from '../lib/api'

interface User {
  id: number
  email: string
  name: string
  username: string
  username_set: boolean
  created_at: string
}

interface AuthContextType {
  user: User | null
  login: () => Promise<void>
  logout: () => void
  isLoading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check if user is already logged in
    checkAuthStatus()
  }, [])

  const checkAuthStatus = async () => {
    try {
      const currentUser = await apiClient.getCurrentUser()
      setUser(currentUser)
    } catch (error) {
      // User not authenticated
      setUser(null)
    } finally {
      setIsLoading(false)
    }
  }

  const login = async () => {
    try {
      setIsLoading(true)
      const result = await apiClient.demoLogin()
      setUser(result.user)
    } catch (error) {
      console.error('Login failed:', error)
      // For demo purposes, create a mock user
      const mockUser: User = {
        id: 1,
        email: "demo@magizh.app",
        name: "Demo User",
        username: "demo_user",
        username_set: true,
        created_at: new Date().toISOString()
      }
      setUser(mockUser)
    } finally {
      setIsLoading(false)
    }
  }

  const logout = async () => {
    try {
      await apiClient.logout()
    } catch (error) {
      console.error('Logout error:', error)
    } finally {
      setUser(null)
    }
  }

  return (
    <AuthContext.Provider value={{ user, login, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}