from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from database import engine
import models
from jobs import job_scheduler

from routers import auth, decks, cards, quiz, users, import_export

# Create database tables
models.Base.metadata.create_all(bind=engine)

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    job_scheduler.start()
    yield
    # Shutdown
    job_scheduler.shutdown()

app = FastAPI(
    title="Magizh Quiz API", 
    version="1.0.0",
    description="A comprehensive quiz and flashcard application with spaced repetition and gamification",
    lifespan=lifespan
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5000", "http://localhost:3000", "https://*.replit.dev"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth.router, prefix="/api/auth", tags=["auth"])
app.include_router(decks.router, prefix="/api/decks", tags=["decks"])
app.include_router(cards.router, prefix="/api/cards", tags=["cards"])
app.include_router(quiz.router, prefix="/api/quiz", tags=["quiz"])
app.include_router(users.router, prefix="", tags=["users"])  # GitHub-style user profiles
app.include_router(import_export.router, prefix="/api/import", tags=["import/export"])

@app.get("/health")
async def health_check():
    return {"status": "healthy", "message": "Magizh Quiz API is running"}

@app.get("/")
async def root():
    return {
        "message": "Welcome to Magizh Quiz API",
        "version": "1.0.0",
        "docs": "/docs",
        "features": [
            "Google OAuth Authentication",
            "Spaced Repetition Learning",
            "Gamification & Achievements", 
            "GitHub-style User Profiles",
            "Comprehensive Analytics",
            "CSV Import/Export",
            "Multiple Quiz Modes"
        ]
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)